from setuptools import setup, find_packages

setup(
    name='odoo',
    version='0.2.1',
    packages=find_packages(),
)
